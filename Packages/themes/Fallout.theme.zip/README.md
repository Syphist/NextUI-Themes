## Preview

![Fallout.theme](./preview.png)

Wallpapers modified from [Consolized.theme](https://github.com/Leviathanium/NextUI-Themes/tree/main/Catalog/Themes/Consolized.theme) by Gamnrd