# NextUI Nao-Black Template

This is a simple and clean theme for NextUI, illustrating systems with pictures and solid colors.

It includes vanilla overlays & tone-down white led settings.

![preview](https://github.com/user-attachments/assets/8328129b-53cd-41f6-9864-ab80d1ac5df5)

Thanks to Leviathanium for the template :)
